/*
Allison Sharpe
10-9-14
Expressions_Wacky
 */

//Person one has five milk duds, person two has two bags of skittles, and person three has three packs of airheads.
//I am calculating these amounts to find the total amount of candy

var personOne = 5;//The total amount for person one
var personTwo = 2;//The total amount for person two
var personThree = 3;//The total amount for person three
var amount = 5 + 2 + 3;//The total amount of candy added together for all three people
console.log(amount);


var total = prompt("If I added 5 boxes of milk duds, 2 bags of skittles, and 3 packs of airheads, what will be my total amount?");
console.log(total);


//Store one has 15 bars of hershey's, store two has 20 boxes of skittles, and store three has 25 things of suckers.
//I am calculating these amounts to find the total amount of candy

var storeOne = 15;//The total amount for store one
var storeTwo = 20;//The total amount for store two
var storeThree = 25;//The total amount for store three
var addedAmount = 15 + 20 + 25;//The total amount added together for all three stores
console.log(addedAmount);


var storeAmount = prompt("If I added 15 bars of hershey's, 20 bags of skittles, and 25 things of suckers, what will be my total amount?");
console.log(storeAmount);


//Add both total amounts from prompt one and two together

var totalAmount = prompt("If I added the total amounts from prompt one and two, what will be my total amount?");
console.log(totalAmount);
