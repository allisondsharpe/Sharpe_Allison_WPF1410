/*
Allison Sharpe
10-9-14
Expressions_Personal
 */

//I am measuring the width, height, and length of my dining room in order to find the area.

var userInput = prompt("What is 15sq.ft. x 12sq.ft."); //This will prompt the user to enter the product for 15 x 12
console.log(userInput);

var width = 15; //This is the width of my dining room
var length = 12; //This is the length of my dining room
var height = 8; //This is the height of my dining room
var area = 15 * 12 * 8;
console.log(area);

var result = prompt("What is 180 sq.ft. x 8sq.ft.");//This will prompt the user to enter the complete area for dining room
console.log(result);

alert("The area of my dining room is 1,440 sq.ft.");
console.log(alert);//This will prompt the user that the area in total is 1,440sq.ft.